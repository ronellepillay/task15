// reducer.js

// Define the initial state
const initialState = {
  balance: 0,
};

// Define the reducer function
const reducer = (state = initialState, action) => {
  switch (action.type) {
    case 'DEPOSIT':
      return { balance: state.balance + action.amount };
    case 'WITHDRAW':
      return { balance: state.balance - action.amount };
    case 'ADD_INTEREST':
      return { balance: state.balance * 1.05 };
    case 'CHARGES':
      return { balance: state.balance * 0.85 };
    default:
      return state;
  }
};

export default reducer;
