import React, { useState } from 'react';
import { useSelector, useDispatch } from 'react-redux';
import { deposit, withdraw, addInterest, charges } from './actions'; // Import action creators
import './App.css';

const App = () => {
  const balance = useSelector((state) => state.balance);
  const dispatch = useDispatch();
  const [amount, setAmount] = useState(0);

  const handleDeposit = () => {
    dispatch(deposit(parseInt(amount))); // Dispatch deposit action creator with the entered amount
    setAmount(0);
  };

  const handleWithdraw = () => {
    dispatch(withdraw(parseInt(amount))); // Dispatch withdraw action creator with the entered amount
    setAmount(0);
  };

  const handleAddInterest = () => {
    dispatch(addInterest()); // Dispatch addInterest action creator
  };

  const handleCharges = () => {
    dispatch(charges()); // Dispatch charges action creator
  };

  return (
    <div>
      <h1>Account Balance: {balance}</h1>
      <input type="number" value={amount} onChange={(e) => setAmount(e.target.value)} />
      <button onClick={handleDeposit}>Deposit</button>
      <button onClick={handleWithdraw}>Withdraw</button>
      <button onClick={handleAddInterest}>Add Interest</button>
      <button onClick={handleCharges}>Charges</button>
    </div>
  );
};

export default App;

