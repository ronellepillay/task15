// actions.js

export const deposit = (amount) => {
  return {
    type: 'DEPOSIT',
    amount: amount,
  };
};

export const withdraw = (amount) => {
  return {
    type: 'WITHDRAW',
    amount: amount,
  };
};

export const addInterest = () => {
  return {
    type: 'ADD_INTEREST',
  };
};

export const charges = () => {
  return {
    type: 'CHARGES',
  };
};
